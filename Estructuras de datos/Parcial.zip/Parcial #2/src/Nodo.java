public class Nodo {
    int indice;
    int valor;
    Nodo siguiente;

    public Nodo(int indice, int valor) {
        this.indice = indice;
        this.valor = valor;
        this.siguiente = null;
    }

}
